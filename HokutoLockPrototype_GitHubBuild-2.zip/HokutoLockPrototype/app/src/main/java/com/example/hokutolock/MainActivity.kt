
package com.example.hokutolock

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var entered = ""
    private val demoPin = "2580" // Prototype-only code, not the phone's real PIN.
    private lateinit var dots: TextView
    private val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 85)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        dots = findViewById(R.id.dots)
        val grid = findViewById<GridLayout>(R.id.keypad)

        val keys = listOf("1","2","3","4","5","6","7","8","9","CLR","0","⌫")
        keys.forEach { key ->
            val b = Button(this)
            b.text = key
            b.textSize = if (key.length == 1) 24f else 15f
            b.setTextColor(Color.WHITE)
            b.gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(225, 145, 12, 12))
                setStroke(3, Color.rgb(220, 190, 165))
            }
            b.background = bg
            val p = GridLayout.LayoutParams().apply {
                width = 0
                height = 118
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8,8,8,8)
            }
            b.layoutParams = p
            b.setOnClickListener { handleKey(key, b) }
            grid.addView(b)
        }
    }

    private fun handleKey(key: String, view: View) {
        view.animate().scaleX(0.88f).scaleY(0.88f).setDuration(60).withEndAction {
            view.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
        }.start()

        when (key) {
            "CLR" -> entered = ""
            "⌫" -> if (entered.isNotEmpty()) entered = entered.dropLast(1)
            else -> if (entered.length < 4) {
                entered += key
                // Placeholder attack sound. Replace with ata_1/ata_2/ata_3/finish audio assets later.
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 70)
                if (entered.length == 4) {
                    if (entered == demoPin) {
                        // Placeholder for "finish + bell" and successful prototype transition.
                        tone.startTone(ToneGenerator.TONE_PROP_ACK, 300)
                        Toast.makeText(this, "BATTLE BONUS GET!!", Toast.LENGTH_SHORT).show()
                    } else {
                        tone.startTone(ToneGenerator.TONE_PROP_NACK, 250)
                    }
                    entered = ""
                }
            }
        }
        dots.text = (0 until 4).joinToString("  ") { if (it < entered.length) "●" else "○" }
    }

    override fun onDestroy() {
        tone.release()
        super.onDestroy()
    }
}
