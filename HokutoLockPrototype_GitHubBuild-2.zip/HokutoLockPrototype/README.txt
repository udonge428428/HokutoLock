
Hokuto Lock Prototype v0.1

This is an Android Studio source prototype, not a replacement for Android's secure lock screen.
Demo code: 2580

Current behavior:
- Full-screen pachislot-inspired visual
- Working 0–9 keypad, CLR and backspace
- Four input indicators
- Button press animation
- Placeholder sounds
- 4-digit code check

Next asset slots:
- BB background/video
- BGM
- attack 1 / attack 2 / attack 3
- finish voice + bell

For safety, do not store or request the phone's real PIN in this app.
